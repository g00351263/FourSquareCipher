package ie.gmit.sw;

public class Runner {

	public static void main(String[] args) throws Exception {

		new Menu().menu();

		
	}

}
